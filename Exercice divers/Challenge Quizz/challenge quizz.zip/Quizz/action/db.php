<?php
$pdo = new PDO('mysql:host=localhost;dbname=todolist', 'root', 'root');